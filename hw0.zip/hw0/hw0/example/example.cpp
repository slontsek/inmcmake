#include<stdlib.h>
#include<iostream>

#include "CSRMatr.h"
//#include "sparskit_wrapper.h"

using namespace std;

int main(){
    CSRMatr A;
    double x[3] = {1, 1, 1};
    double* y = new double[*A.ret_n()];
    y = A * x;
    for(int i = 0; i < 3; i++){
        cout << y[i] << " ";
    }
    cout<< "\n";
    return 0;
}