//amux (n, x, y, a, ja, ia)
#include "CSRMatr.h"

double* CSRMatr::ret_A(){
    return A;
}

int* CSRMatr::ret_jA(){
    return jA;
}

int* CSRMatr::ret_iA(){
    return iA;
}

int* CSRMatr::ret_n(){
    return &n;
}