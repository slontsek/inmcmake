extern "C"{
    void amux_(int*, double*, double*, double*, int*, int*);
}

//double* operator*(CSRMatr A, double* x);