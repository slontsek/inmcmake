#include "CSRMatr.h"
#include "sparskit_wrapper.h"
#include<iostream>

double* operator*(CSRMatr A, double* x){
    double* y = new double[*A.ret_n()];
    #ifdef WITH_SPARSKIT
        amux_(A.ret_n(), x, y, A.ret_A(), A.ret_jA(), A.ret_iA());
    #else
        std::cout<<"error\n";
    #endif
    return y;
}