class CSRMatr{
private:
    int n = 3;
    double A[5] = {1, 2, 4, 2, 6};
    int jA[5] = {1, 2, 2, 2, 3};
    int iA[4] = {1, 3, 4, 6};
public:
    double* ret_A();
    int* ret_jA();
    int* ret_iA();
    int* ret_n();
};

double* operator*(CSRMatr A, double* x);